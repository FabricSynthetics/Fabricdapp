
Q1 2022
Mobile support for synthetics dapp
Release FABRIC synthetics SDK 
Publish and verify IDLs with Anchor registry
Launch support for additional collateral
Launch additional synthetics to trade
Open source contract and dApp code
Launch FAB-USDC LP pool
Audit FABRIC synthetics dApp
Launch FABRIC synthetics dApp on mainnet
Launch FABRIC single side staking on mainnet
Launch SPL Synthetic swaps on mainnet
Launch FABRIC analytics
Launch FABRIC Swap to LP 
Launch FABRIC DAO/voting on mainnet
Launch FABRIC smart swap router

Q2 2022
Launch trader-focussed platform for synthetics
fUSD integration with Mercurial
fUSD integration with Parrot Finance
fUSD integration with Larix
Add mSOL as collateral + mSOL rewards program
Discord tip bot
NFT Sales bot
Launch fUSD-USDC LP pool

Q3 2022
Launch limit order support for synthetic markets
Launch revamped liquidity mining

Q4 2022
Launch FABRIC borrowing/lending platform
Launch FAB PUNK staking
Launch Defi learning platform

2023
Launch concerntrated liquidity vAMM
Multichain support - ETH
Multichain support - AVAX
Launch options market for synthetic assets